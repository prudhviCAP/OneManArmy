package com.cg.insurance.bean;

public class PremiumBean {

	private int policyQuestion;
	private String answer;
	
	public int getPolicyQuestion() {
		return policyQuestion;
	}
	public void setPolicyQuestion(int i) {
		this.policyQuestion = i;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	@Override
	public String toString() {
		return "PremiumBean [policyQuestion=" + policyQuestion + ", answer=" + answer + "]";
	}

	
}
